<form method="post" id="referral-form">
    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" id="first_name" required>
    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" id="last_name" required>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required>
    <label for="referral_code">Referral Code:</label>
    <input type="text" name="referral_code" id="referral_code">
    <input type="submit" value="Register">
</form>
<div id="referral-code-validation"></div>
