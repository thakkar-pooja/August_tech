<?php
/*
Plugin Name: Referral Plugin
Description: A referral system plugin with a registration form and referral code validation.
Version: 1.0
Author: Pooja Thakkar
*/

if (!defined('ABSPATH')) {
    exit;
}

define('REFERRAL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('REFERRAL_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once REFERRAL_PLUGIN_DIR . 'includes/class-referral-list-table.php';
require_once REFERRAL_PLUGIN_DIR . 'includes/class-referral-handler.php';
require_once REFERRAL_PLUGIN_DIR . 'includes/ajax-handler.php';

// Register activation hook
register_activation_hook(__FILE__, 'referral_plugin_create_table');

// Create custom table for referrals
function referral_plugin_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'referrals';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        referral_code varchar(32) NOT NULL,
        referred_user_id bigint(20) DEFAULT NULL,
        commission_amount decimal(10,2) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY referral_code (referral_code)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Register shortcode
function register_referral_form_shortcode() {
    ob_start();
    include REFERRAL_PLUGIN_DIR . 'templates/referral-form.php';
    return ob_get_clean();
}
add_shortcode('referral_form', 'register_referral_form_shortcode');

// Enqueue scripts and styles
function referral_plugin_enqueue_scripts() {
    wp_enqueue_style('referral-plugin-styles', REFERRAL_PLUGIN_URL . 'css/styles.css');
    wp_enqueue_script('referral-plugin-scripts', REFERRAL_PLUGIN_URL . 'js/scripts.js', array('jquery'), null, true);
    wp_localize_script('referral-plugin-scripts', 'referral_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'referral_plugin_enqueue_scripts');

// Add settings field
function referral_plugin_settings() {
    add_settings_section('referral_settings_section', 'Referral Settings', null, 'general');
    add_settings_field('join_commission', 'Join Commission', 'display_join_commission_field', 'general', 'referral_settings_section');
    register_setting('general', 'join_commission');
}
add_action('admin_init', 'referral_plugin_settings');

function display_join_commission_field() {
    $join_commission = get_option('join_commission', '50');
    echo '<input type="text" id="join_commission" name="join_commission" value="' . $join_commission . '" />';
}

// Handle form submission
function handle_referral_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'referrals';

        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $password = $_POST['password']; // Ensure to hash the password before storing
        $referral_code = sanitize_text_field($_POST['referral_code']);

        // Check if the referral code is valid
        $referrer = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table_name WHERE referral_code = %s", $referral_code));

        if ($referrer) {
            // Create new user and store user data
            $user_id = wp_create_user($email, $password, $email);
            if (!is_wp_error($user_id)) {
                // Generate a unique referral code for the new user
                $new_referral_code = Referral_Handler::generate_referral_code();

                // Store referral information
                $wpdb->insert($table_name, array(
                    'user_id' => $user_id,
                    'referral_code' => $new_referral_code,
                    'referred_user_id' => $referrer->id,
                    'commission_amount' => get_option('join_commission', '50')
                ));
            }
        }
    }
}
add_action('init', 'handle_referral_form_submission');
