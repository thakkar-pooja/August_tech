<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'referrals';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

delete_option('join_commission');
?>
