<?php

class Referral_Handler {

    public static function generate_referral_code() {
        return substr(md5(uniqid(mt_rand(), true)), 0, 10);
    }


    public static function validate_referral_code($code) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'referrals';
        $result = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE referral_code = %s", $code));
        return $result > 0;
    }
}
?>
