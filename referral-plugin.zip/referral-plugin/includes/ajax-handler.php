<?php

add_action('wp_ajax_validate_referral_code', 'validate_referral_code');
add_action('wp_ajax_nopriv_validate_referral_code', 'validate_referral_code');

function validate_referral_code() {
    global $wpdb;
    $referral_code = sanitize_text_field($_POST['referral_code']);
    $table_name = $wpdb->prefix . 'referrals';

    $referrer = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table_name WHERE referral_code = %s", $referral_code));

    if ($referrer) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
    wp_die();
}

?>
