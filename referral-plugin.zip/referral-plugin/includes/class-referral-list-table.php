<?php

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Referral_List_Table extends WP_List_Table {
    function get_columns() {
        return array(
            'username' => 'Username',
            'referral_username' => 'Referral Username',
            'join_commission' => 'Join Commission (₹)',
            'action' => 'Action'
        );
    }

    function prepare_items() {
        // Retrieve data from the database and set items for display
        $this->items = get_referral_history();
    }

    function column_default($item, $column_name) {
        switch($column_name) {
            case 'username':
            case 'referral_username':
            case 'join_commission':
                return $item[$column_name];
            case 'action':
                return sprintf('<a href="?page=%s&action=%s&user=%s">Edit</a> | <a href="?page=%s&action=%s&user=%s">Delete</a>',
                    $_REQUEST['page'], 'edit', $item['ID'], $_REQUEST['page'], 'delete', $item['ID']);
            default:
                return print_r($item, true);
        }
    }
}

function get_referral_history() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'referrals';
    return $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
}
?>
