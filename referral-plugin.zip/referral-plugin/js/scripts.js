jQuery(document).ready(function($) {
    $('#referral_code').on('blur', function() {
        var referral_code = $(this).val();
        $.ajax({
            url: referral_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'validate_referral_code',
                referral_code: referral_code
            },
            success: function(response) {
                if (response.success) {
                    $('#referral-code-validation').text('Referral code is valid').css('color', 'green');
                } else {
                    $('#referral-code-validation').text('Referral code is invalid').css('color', 'red');
                }
            }
        });
    });
});
